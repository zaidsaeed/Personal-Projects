import java.util.NoSuchElementException;
import java.util.*;

/** Implements the interface <code>FrequencyTable</code> using a
 *  binary search tree.
 *
 * @author Marcel Turcotte (turcott@eecs.uottawa.ca)
 */

public class TreeFrequencyTable implements FrequencyTable {

    // Stores the elements of this binary search tree (frequency
    // table)
    
    private static class Elem {
    
        private String key;
        private long count;
    
        private Elem left;
        private Elem right;
    
        private Elem(String key) {
            this.key = key;
            this.count = 0;
            left = null;
            right = null;
        }

        public String toString(){
            return key + ";" + count;
        }
    }

    private Elem root = null; // A reference to the root element
    private int size = 0; // The size of the tree

    /** The size of the frequency table.
     *
     * @return the size of the frequency table
     */
    
    public int size() {
        return size;
    }


    public static void main(String args[]){
        TreeFrequencyTable tree = new TreeFrequencyTable();
        tree.init("a");
        tree.init("b");
        tree.init("c");
        System.out.println(tree);

    }
  
    /** Creates an entry in the frequency table and initializes its
     *  count to zero.
     *
     * @param key key with which the specified value is to be associated
     */
  
    public void init(String key) {

        Elem current = root;
        if(current == null){
            root = new Elem(key);
            size++;
        }else{
            boolean complete = false;
            while( !complete ){
                int test = key.compareTo(current.key);
                if(test == 0){
                    current.count++;
                    complete = true;
                }
                else if (test < 0){
                    if(current.left == null){
                        current.left = new Elem(key);
                        size++;
                        complete = true;
                    }else{
                        current = current.left; 
                    }
                    
                }else{
                    if(current.right == null){
                        current.right = new Elem(key);
                        size++;
                        complete = true;
                    }else{
                        current = current.right;
                    }

                }
            }
    }

    }

    public void inOrder(){
        inOrder(root);
    }

    private void inOrder(Elem current){
        if(current != null){
            inOrder(current.left);
            System.out.println(current);
            inOrder(current.right);
        }
    }

  
    /** The method updates the frequency associed with the key by one.
     *
     * @param key key with which the specified value is to be associated
     */
  
    public void update(String key){
        Elem current = root;
        if(key == null){
            throw new NullPointerException();
        }
        if(current == null){
            throw new NullPointerException();
        }else{
            boolean foundToUpdate = false;
            while(!foundToUpdate){
                int test = key.compareTo(current.key);
                if(test == 0){
                    current.count++;
                    foundToUpdate = true;
                }else if(test < 0){
                    if(current.left == null){
                        throw new NullPointerException();
                    }else{
                    current = current.left;
                    }

                }else{
                    if(current.right == null){
                        throw new NullPointerException();
                    }else{
                        current = current.right;
                    }

            }

            }
        }

    }

  
    /**
     * Looks up for key in this TreeFrequencyTable, returns associated value.
     *
     * @param key value to look for
     * @return value the value associated with this key
     * @throws NoSuchElementException if the key is not found
     */
  
    public long get(String key) {
        Elem current = root;
        long toReturn = (long) 0;
        if(key == null){
            throw new NullPointerException();
        }
        if(current == null){
            throw new NullPointerException();
        }
            else{
            boolean found = false;
            while(!found){
                int test = key.compareTo(current.key);
                if(test == 0){
                    toReturn =current.count;
                    found = true;
                }else if(test < 0){
                    if(current.left == null){
                        throw new NullPointerException();
                    }else{
                        current = current.left;
                    }

                }else{
                    if(current.right == null){
                        throw new NullPointerException();
                    }else{
                        current = current.right;
                    }
                }
            }

        }

        return toReturn;
    }
    
    /*private String getKey(Elem cosidered){
        return cosidered.key;
    }*/

    LinkedList<String> keys= new LinkedList<String>();
    

    /** Returns the list of keys in order, according to the method compareTo of the key
     *  objects.
     *
     *  @return the list of keys in order
     */

    public LinkedList<String> keys() {
        keys(root);
        return keys;
    }
        
    private void keys(Elem c){
        
        if(c!= null){
            keys(c.left);
            keys.addLast(c.key);
            keys(c.right);
        }
        
    }

    /** Returns the values in the order specified by the method compareTo of the key
     *  objects.
     *
     *  @return the values
     */
    long [] counts;
    public long[] values() {
        counts = new long[size];
        values(root);
        return counts;
    }

    
    int i = -1;

    private void values(Elem c){
        if(c!= null){
            values(c.left);
            i++;
            counts[i]=(c.count);
            values(c.right);
        }
        
    }


    /** Returns a String representation of the tree.
     *
     * @return a String representation of the tree.
     */

    public String toString() {
        return toString( root );
    }

    // Helper method.
  
    private String toString(Elem current) {
    
        if (current == null) {
            return "{}";
        }
    
        return "{" + toString(current.left) + "[" + current.key + "," + current.count + "]" + toString(current.right) + "}";
    }
  
}
