
public class StudentInfo {

    /**
     * Displays the student information: student name, id, section, etc for each
     * member of the team.
     */

    public static void display() {

        System.out.println("************************************************************");
        System.out.println("* Shaafici Ali,8666419,Section:A00*");
        System.out.println("* Zaid Nidal Saeed,8621155,Section A00*");
        System.out.println("*                                                          *");
        System.out.println("*                                                          *");
        System.out.println("************************************************************");
        System.out.println();

    }
    public static void main(String[] args)
    {
        display();
    }
}