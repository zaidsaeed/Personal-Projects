import java.util.NoSuchElementException;
import java.util.*;


/** Implements the interface <code>FrequencyTable</code> using linked
 *  elements. The linked structure is circular and uses a dummy node.
 *
 * @author Marcel Turcotte (turcott@eecs.uottawa.ca)
 */

public class LinearFrequencyTable implements FrequencyTable {

    // Linked elements

    private static class Elem {

	private String key;
	private long count;
	private Elem previous;
	private Elem next;

	private Elem(String key, Elem previous, Elem next) {
	    this.key = key;
	    this.count = 0;
	    this.previous = previous;
	    this.next = next;
	}

    }

    private Elem head;
    private int size;

    

    /** Constructs and empty <strong>FrequencyTable</strong>.
     */

    public LinearFrequencyTable() {
	head = new Elem(null, null, null); // dummy node
	head.previous = head; // making the dummy node circular
	head.next = head; // making the dummy node circular
	size = 0;
    }

    /** The size of the frequency table.
     *
     * @return the size of the frequency table
     */

    public int size() {
	return size;
    }
  
    /** Returns the frequency value associated with this key.
     *
     *  @param key key whose frequency value is to be returned
     *  @return the frequency associated with this key
     *  @throws NoSuchElementException if the key is not found
     */

    public long get(String key) {
        Elem p = head;
        while(p.next != head){
            p = p.next;
            if( p.key.equals(key) ){
                return p.count;
            }
        }
        throw new NoSuchElementException();
    }

    /** Creates an entry in the frequency table and initializes its
     *  count to zero. The keys are kept in order (according to their
     *  method <strong>compareTo</strong>).
     *
     *  @param key key with which the specified value is to be associated
     *  @throws IllegalArgumentException if the key was alreaddy present
     */

    public void init(String key) throws IllegalArgumentException {
        boolean flag = false;
        Elem p=head.next;
        Elem tmp;
        if(p==head)
        {   
            head.next=new Elem(key,head,head);
            head.previous=head.next;
        }
         else if(p.next==head)
        {
            int test=p.key.compareTo(key);
            if(test<0)
            {
                p.next=new Elem(key,p,head);
                head.previous=p.next;
                flag=true;
            }
            else if(test>0)
            {
                tmp=new Elem(key,head,p);
                p.previous=tmp;
                head.next =  tmp;
                flag=true;
                System.out.println(2);
                //p.next=head;
            }
            else{
                throw new IllegalArgumentException();
            }
        }

        else
        {
            while(p.next!=head)
            {
                if(p.next.key.compareTo(key)<0)
                {
                    p=p.next;
                }
                else if(p.next.key.compareTo(key)>0)
                {
                    tmp=new Elem(key,p,p.next);
                    p.next.previous = tmp;
                    p.next=tmp;
                    p = head.previous; //check this line
                    flag = true;

                }
                else
                {
                    throw new IllegalArgumentException();
                }

            }

            

        }
        if(p.next==head && flag == false)
            {
                tmp=new Elem(key,head.previous,head);
                head.previous.next=tmp;
                head.previous = tmp;
            }
            size++;

    }

    public static void main(String args[]){
        LinearFrequencyTable line = new LinearFrequencyTable();
        line.init("c");
        
        line.init("a");

        line.init("b");
        
        line.init("z");

        line.init("g");

        line.init("d");

        line.init("e");

        
        System.out.println(line);
    }

    /** The method updates the frequency associed with the key by one.
     *
     *  @param key key with which the specified value is to be associated
     *  @throws NoSuchElementException if the key is not found
     */
    public void update(String key) {
	   Elem p = head.next;
       while(p != head && ! p.key.equals(key)){
            p =p.next;
       }
       if(p == head){ //This means that we traversed through the entire list and did not find the key that we were looking for
            throw new NoSuchElementException();
       }
       p.count++;
    }

    /** Returns the list of keys in order, according to the method
     *  <strong>compareTo</strong> of the key objects.
     *
     *  @return the list of keys in order
     */

    public LinkedList<String> keys() {
        LinkedList<String> keyValues = new LinkedList<String>();
        Elem p = head.next;
        while(p.next != head){
            keyValues.addLast(p.key);
            p = p.next;
        }
        return keyValues;
    }

    /** Returns an array containing the frequencies of the keys in the
     *  order specified by the method <strong>compareTo</strong> of
     *  the key objects.
     *
     *  @return an array of frequency counts
     */
    
    private long[] counts;
    public long[] values() {
        counts = new long[size()];
        int i = -1;
        Elem p = head.next;
        while(p!= head){
            i++;
            counts[i] = p.count;
            p=p.next;
        }
        return counts;
    }

    /** Returns a <code>String</code> representations of the elements
     * of the frequency table.
     *  
     *  @return the string representation
     */

    public String toString() {

	StringBuffer str = new StringBuffer("{");
	Elem p = head.next;

	while (p != head) {
	    str.append("{key="+p.key+", count="+p.count+"}");
	    if (p.next != head) {
		str.append(",");
	    }
	    p = p.next;
	}
	str.append("}");
	return str.toString();
    }

}