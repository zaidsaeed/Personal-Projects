/** Implements the interface <code>Stack</code> using linked elements.
 *
 *
 * @author  Marcel Turcotte (turcotte@eecs.uottawa.ca)
 */

public class LinkedStack<E> implements Stack<E> {

    // Objects of the class Elem are used to store the elements of the
    // stack.
    
    private static class Elem<T> {
        private T value;
        private Elem<T> next;

        private Elem(T value, Elem<T> next) {
            this.value = value;
            this.next = next;
        }

    }

    // Reference to the top element
    
    private Elem<E> top; 

    /** Returns <code>true</code> if this stack is empty, and
     * <code>false</code> otherwise.
     *
     * @return <code>true</code> if this stack is empty, and
     * <code>false</code> otherwise.
     */

    public boolean isEmpty() {
        return top == null;
    }

    /** Inserts an element onto the stack.
     *
     * @param value the element to be inserted
     */

    public void push(E value) {

	if (value == null) {
	    throw new NullPointerException();
	}
	
        top = new Elem<E>(value, top);
    }

    /** Returns the top element, without removing it.
     *
     * @return the top element
     */

    public E peek() {

	// pre-condition: the stack is not empty
	
        return top.value;
    }

    /** Removes and returns the top element.
     *
     * @return the top element
     */

    public E pop() {

	// pre-condition: the stack is not empty
	
        E saved = top.value;
        top = top.next;
        return saved;

    }

    /** Removes the top element of the stack. The element inserted at
     * the bottom of the stack.
     */
    //private E savedValue = top.value;
    public void roll() {
        Elem<E> elem = this.top;
        //System.out.println(elem.next.value);
        roll(this, elem);  
    }

    private void roll(LinkedStack<E> temp, Elem<E> elem){
        if (elem != null){
            if(elem.next == null){
                elem.next = new Elem<E>(top.value, null);
                top = top.next;
            }else{
                roll(this, elem.next);
            }
        } 
    }

    /** Removes the botttom element. The element is inserted on the
     * top of the stack.
     */
    public void unroll() {
        Elem<E> elem = this.top;
        unroll(this,elem);
    }

    private void unroll(LinkedStack<E> temp, Elem<E> elem){
        if(elem != null && elem.next != null){
            if(elem.next.next == null){
                top = new Elem<E>(elem.next.value,top);
                elem.next = null;
            }else{
                unroll(this, elem.next);
            }
        }

    }


    public static void main(String args[]){
        LinkedStack<Integer> temp = new LinkedStack<Integer> ();
        temp.push(1);
        temp.push(2);
        Elem<Integer> top1 = temp.top;
        while(top1 != null){
            System.out.println(top1.value);
            top1= top1.next;
        }
        temp.roll();
        Elem<Integer> top2 = temp.top;
        while(top2 != null){
            System.out.println(top2.value);
            top2 = top2.next;
        }
    }

    /** Returns a string representation of the stack.
     *
     * @return a string representation
     */

    @Override public String toString() {
	StringBuffer stackStr = new StringBuffer("{");

	Elem<E> current = top;
	
	while (current != null) {
	    stackStr.append(current.value);
	    if (current.next != null) {
		stackStr.append(",");
	    }
	    current = current.next;
	}
	stackStr.append("}");

	return stackStr.toString();
    }
    
}