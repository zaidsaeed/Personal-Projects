Shaafici Ali 8666419 ITI1121 A00
Zaid Saeed 8621155 ITI1121 A00


This assignment introduced helped us prove the birthday paradox using iterative for-loops.