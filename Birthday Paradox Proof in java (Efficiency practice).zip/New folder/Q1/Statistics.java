public class Statistics{
  private int[] s;
  private double avg = 0;
  private double stDEV = 0;


  public double getAVG(){
    return average();
  }

  public double getSTDEV(){
    return standardDeviation();
  }
  


  int index = 0;
  public Statistics(int numberOfRuns){
    s = new int[numberOfRuns];
 }
  
  public void updateStatistics(int value){
    s[index]= value;
    index++;
 }
  
  
  public double average(){
    int sum = 0;
    
    for(int i = 0; i < s.length; i++){
      sum = sum + s[i];
    }
    avg = (double) Math.round((sum/s.length)*100)/100;
    return avg;

 }
  
  
  public double average(double[] s){
    double sum = 0;
    double avg1 = 0;
    for(int i = 0; i < s.length; i++){
      sum = sum + s[i];
    }
    avg1 = (double) Math.round((sum/s.length)*100)/100;
    return avg1;

 }
 
  
  public int min(){
    int x = s[0];
    for(int i = 0; i<s.length; i++){
      if(s[i]<x){
        x = s[i];
      }
    }
    return x;
  }
  
  public int max(){
    int x = s[0];
    for(int i = 0; i<s.length; i++){
      if(s[i]>x){
        x = s[i];
      }
    }
    return x;
  }
  
  
  
  public double standardDeviation(){
    int index = 0;
    double[] t = new double[s.length];
    double x= average();
    for(int i = 0; i<s.length;i++){
      t[index]= java.lang.Math.pow((s[i] - x),(2));
      index++;
    }  
    
    double newAvg = average(t);
    stDEV = (double) (Math.round(java.lang.Math.sqrt(newAvg)*100))/100;
    return stDEV;
  }
  


  public String toString(){
    return ("We have run "+ s.length + " experiments." + System.lineSeparator() + "The minimum was:" + min() + System.lineSeparator()+ "The maximum was:" + max() + 
             System.lineSeparator() + "The mean was:" + average() + System.lineSeparator()+ "The standard deviation was :"+ standardDeviation())  ;
 }
  
}