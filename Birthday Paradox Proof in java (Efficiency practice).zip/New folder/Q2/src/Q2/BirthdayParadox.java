class BirthdayParadox{
  private static java.util.Random generator = new java.util.Random();
  
  /*This function generates an array of birthdays; the length of the array is given by the user. */ 
  public static int[] GenerateBirthdays(int range){
    int[] Array = new int[range];
    int index = 0;
    for(int i =0; i<range; i++){
      Array[index] = generator.nextInt(range)+1;
      index++;
    }
    return Array;
  }
  
  public static int oneRun(int range){
    int c = 0;
    int index = 1;
    int[] s = GenerateBirthdays(range);
    while(index <= (s.length-2)){
    for(int i = 0; i<index; i++){
      if(s[i] == s[index]){
        return c;
      }
    }
        c=c+1;
        index= index+1;  
    }
    return c; 
  }
    
     
    public static Statistics runExperiments(int range, int numberOfRuns){
    Statistics i = new Statistics(numberOfRuns);
    for(int j = 0; j<numberOfRuns; j++){
      i.updateStatistics(oneRun(range));
    }
    return i;
 }

    public static ITI1121Chart runExperiments2(int beginAndIncrement,int limit, int numberOfRuns){
      final int z= beginAndIncrement;
      ITI1121Chart c = new ITI1121Chart("Size vs. Mean With Deviation");
      while(beginAndIncrement<= limit){
          Statistics j = runExperiments(beginAndIncrement,numberOfRuns);
          c.addDataPoint(beginAndIncrement,j.getAVG(),j.getSTDEV());
          beginAndIncrement =  beginAndIncrement + z;
      }
      c.addPolynome(0.5);
      c.addPolynome(0.52);
      c.addPolynome(0.54);
      c.render();

      return c;

    }

    public static void main(String args[]){
  if(args.length == 3){
    int beginAndIncrement= Integer.parseInt(args[0]);
    int limit = Integer.parseInt(args[1]);
    int numberOfRuns = Integer.parseInt(args[2]);
    
    ITI1121Chart i = runExperiments2(beginAndIncrement,limit,numberOfRuns);
    
    }
  else{
      ITI1121Chart i = runExperiments2(100,10000,1000);
      }
    }


  }

    
    
    
    
    