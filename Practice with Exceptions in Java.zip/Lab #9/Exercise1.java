import java.io.IOException;

public class Exercise1{
   static int exceptionNumber;
   public static void main(String args[]) {		
      try{
	randomException();
      }
      catch(ArrayIndexOutOfBoundsException t){
         System.out.println("The exception type is:" + t + ", The exception number is: " + exceptionNumber);
      }
      catch(IllegalArgumentException t){
         System.out.println("The exception type is:" + t + ", The exception number is: " + exceptionNumber);
      }
      catch(IOException t){
         System.out.println("The exception type is:"+ t + ", The exception number is: " + exceptionNumber);
      }
      catch(NullPointerException t){
         System.out.println("The exception type is:" + t + ", The exception number is: " + exceptionNumber);
      }
      catch(Exception t){
         System.out.println("The exception type is:" +t + ", The exception number is: " + exceptionNumber);
      }
   }

   public static void randomException() throws Exception, ArrayIndexOutOfBoundsException, IOException,IllegalArgumentException,  NullPointerException  {
      exceptionNumber=(int)(Math.random()*5) + 1;
      if(exceptionNumber==1){
	throw new Exception(); 
      }
      if(exceptionNumber==2){
	throw new ArrayIndexOutOfBoundsException(); 
      }
      if(exceptionNumber==3){
	throw new IOException(); 
      }
      if(exceptionNumber==4){
	throw new IllegalArgumentException(); 
      }
      if(exceptionNumber==5){
	throw new NullPointerException(); 
      }      
   }
}