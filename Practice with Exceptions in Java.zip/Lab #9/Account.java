public class Account{
	static int balance;
	public Account(){
		balance = 0;
	}

	public void withdraw(int x){
		int t = balance - x;
		if(t < 0){
			throw new NotEnoughMoneyException(x);
		}
		balance = t;
	}

	public void deposit(int x){
		balance = balance + x;
	}



}


class NotEnoughMoneyException extends IllegalStateException{
	int withdrawnAmount;
	int balancePrior;
	int missingAmount;
	public NotEnoughMoneyException(int x){
		super("The given account does not have the sufficient amount of money.");
		withdrawnAmount = x;
		balancePrior = Account.balance;
		missingAmount = withdrawnAmount - balancePrior;
	}

	public int getAmount(){
		System.out.println(balancePrior);
		return withdrawnAmount;
	}

	public int getBalance(){
		System.out.println(balancePrior);
		return balancePrior;
	}

	public int getMissingAmount(){
		return missingAmount;
	}
}
