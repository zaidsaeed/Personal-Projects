//import LinkedStack.Elem;

/**
 * ITI 1121. Introduction � l'informatique II
 * ITI 1521. Introduction to Computer Science II
 *
 * @author Marcel Turcotte, Universit� d'Ottawa/University of Ottawa
 */

public class DynamicArrayStack<E> implements Stack<E> {

    // Instance variables

    private E[] elems;  // Used to store the elements of this ArrayStack
    private int top;    // Designates the first free cell
    private static final int DEFAULT_INC = 25;   //Used to store default increment / decrement

    @SuppressWarnings( "unchecked" )

    // Constructor

    public DynamicArrayStack() {
        elems = (E[]) new Object[ DEFAULT_INC ];
        top = 0;
    }

    // Returns true if this DynamicArrayStack is empty

    public boolean isEmpty() {

        // Same as:
        // if ( top == 0 ) {
        //     return true;
        // } else {
        //     return false;
        // }

        return ( top == 0 );
    }

    // Returns the top element of this ArrayStack without removing it

    public E peek() {

        // pre-conditions: ! isEmpty()

        return elems[ top-1 ];
    }

    // Removes and returns the top element of this stack

    public E pop() {
        // pre-conditions: ! isEmpty()
        
        // *first* decrements top, then access the value!
        E saved = elems[ --top ];

        elems[ top ] = null; // scrub the memory!
        
        // When your array is full, a new array with DEFAULT_INC 
        // plus elements will be created and filled with the elements 
        // of the previous array.
    	if (elems.length - (top+1) == DEFAULT_INC) {
    		decreaseCapacity();
    	}
        return saved;
    }
    
    @SuppressWarnings( "unchecked" )
    
    private void decreaseCapacity() {
		E[] copy; 
		copy = (E[]) new Object[ elems.length - DEFAULT_INC ];
		System.arraycopy(elems, 0, copy, 0, top);
		elems=copy;		
    }

    // Puts the element onto the top of this stack.

    public void push( E element ) {
        // Pre-condition: the stack is not full

        // *first* stores the element at position top, then increments top
        elems[ top++ ] = element;
        
        // When an array has DEFAULT_INC elements less than its size, 
        // the array must automatically be shrunk.
    	if (top == elems.length) {
    		increaseCapacity();
    	}
    }
    
    @SuppressWarnings( "unchecked" )
    
    private void increaseCapacity() {
    	E[] copy; 
		copy = (E[]) new Object[ top + DEFAULT_INC ];
		System.arraycopy(elems, 0, copy, 0, top);
		elems=copy;	
    }

    @SuppressWarnings( "unchecked" )
    
    public void clear() {

    	elems = (E[]) new Object[DEFAULT_INC]; // New array with min size DEFAULT_INC

        top = 0;

    }
    
    /**
     * Returns a string representation of this object.
     *
     * @return a string representation of this object.
     */
    @Override
    public String toString() {

        StringBuffer b;
        b = new StringBuffer("DynamicArrayStack: {");

        int p;
        p = top;
        while (p != 0) {
        	p = p-1;
            if (p != top-1) {
                b.append(",");
            }
            b.append(elems[p]);         
        }

        b.append("}");
        return b.toString();
    }

}
