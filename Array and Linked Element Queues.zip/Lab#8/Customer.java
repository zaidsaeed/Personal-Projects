import java.util.Random;

public class Customer{

	private static int arrivalTime;
	private static int initialNumberOfItems;
	private static int numberofItems;
	private static int numberOfServedItems = 0;

	private static final int MAX_NUM_ITEMS =1000;
	
	Random generator = new Random();
	
	public Customer(int arrivalTime){
		this.arrivalTime = arrivalTime;
		initialNumberOfItems = generator.nextInt(MAX_NUM_ITEMS)+1;
	}

	public int getArrivalTime(){
		return arrivalTime;
	}

	public int getNumberOfItems(){
		return (initialNumberOfItems - numberOfServedItems);
	}

	public int getNumberOfServedItems(){
		return numberOfServedItems;
	}

	public void serve(){
		numberOfServedItems++;
	}

	public static void main(String args[]){
		Customer c = new Customer(5);
		System.out.println(c.getNumberOfItems());
		for(int i = 0; i< 5; i++){
			c.serve();
		}
		System.out.println(c.getNumberOfItems());

	}

}