public class Cashier{
	private ArrayQueue<Customer> queue;
	private Customer currentCustomer;
	private int totalCustomerWaitTime;
	private int customersServed;

	public Customer current;
	private static int totalWaitTime;
	private static int totalItemsServed;
	private static int totalCustomerServed;

	public Cashier(){
		queue = new ArrayQueue<Customer>();

	}

	public void addCustomer(Customer c){
		queue.enqueue(c);
	}

	public int getQueueSize(){
		return queue.size;
	}

	public void serveCustomers(int currentTime){
			totalItemsServed=0;
			totalCustomerServed = 0;
			totalWaitTime = totalWaitTime + currentTime;
			while(!queue.isEmpty()){	
				current = queue.dequeue();
				totalCustomerServed++;
				if(current != null){
					while(current.getNumberOfItems()>0){
						current.serve();
						totalItemsServed++;
						totalWaitTime++;
					}	
				}

		}
		
				
	}

	public int getTotalWaitTime(){
		return totalWaitTime;
	}

	public int getTotalItemsServed(){
		return totalItemsServed;
	}

	public int getTotalCustomerServed(){
		return totalCustomerServed;
	}

	public String toString(){
		return "The total number of customers served is : " + getTotalCustomerServed() +
		"The average number of items per customer was:" + getTotalItemsServed()/getTotalCustomerServed() + 
		"The average waiting time in seconds was: " + getTotalWaitTime();
	}

	public static void main(String args[]){
		Customer p = new Customer(10);
		Cashier s = new Cashier();
		for(int i =0; i <10; i++){
			s.addCustomer(p);
		}
		s.serveCustomers(5);
		System.out.println(s);
	}


}